## Category 2: Morning brief
# Group 2.4:  banking_group

#scrapy crawl vingroup -o data_vin.csv -a limit 150
#scrapy crawl financevietstock -a group=vin -a start_url=https://finance.vietstock.vn/VIC/tin-tuc-su-kien.htm -o data_vic_finacevietstock.csv
#scrapy crawl financevietstock -a group=vin -a start_url=https://finance.vietstock.vn/VRE/tin-tuc-su-kien.htm -o data_vre_finacevietstock.csv
#scrapy crawl financevietstock -a group=vin -a start_url=https://finance.vietstock.vn/VHM/tin-tuc-su-kien.htm -o data_vhm_finacevietstock.csv


